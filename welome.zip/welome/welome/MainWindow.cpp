#include "mainwindow.h"
MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)


{
    ui->setupUi(this);
    read1();
    stackedWidget = new QStackedWidget(this);
    stackedWidget_2 = new QStackedWidget(this);
    //setCentralWidget(stackedWidget);


    connect(ui->pushButton, &QPushButton::clicked, this, [this]() {stackedWidget->setCurrentIndex(3); });
    connect(ui->pushButton_2, &QPushButton::clicked, this, [this]() {stackedWidget->setCurrentIndex(6); });
    connect(ui->pushButton_3, &QPushButton::clicked, this, [this]() {stackedWidget->setCurrentIndex(1); });
    connect(ui->pushButton_4, &QPushButton::clicked, this, [this]() {stackedWidget->setCurrentIndex(0); });
    //connect(ui->pushButton_5, &QPushButton::clicked, this, [this](){stackedWidget->setCurrentIndex(4); });
    connect(ui->pushButton_6, &QPushButton::clicked, this, [this]() {stackedWidget->setCurrentIndex(4); });
    connect(ui->pushButton_7, &QPushButton::clicked, this, [this]() {stackedWidget->setCurrentIndex(2); });
    connect(ui->pushButton_10, &QPushButton::clicked, this, [this]() {stackedWidget_2->setCurrentIndex(1); });

    //QSet the initial page
  //setPageHome();
}
//setPageHome();
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_8_clicked()
{
    QString Question = ui->lineEdit->text();
   
    User[currentID - 1].sentquestions.push_back(Question);
    Sentmessages m1;
    m1.message = Question;
    m1.id_messsage = User[currentID - 1].sentquestions.size() - 1;

    m1.id_user = currentID;
    if (User[currentID - 1].contact.size() == 0)
    {
        QMessageBox msgBox;
        msgBox.setWindowTitle("Warning");
        msgBox.setText("you do not have any recipient");
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Ok);
        //if (msgBox.exec() == QMessageBox::Ok) {
        //	// do something
        //}
        //else {
        //	// do something else
        //}
    }
    else {
        int userId;
        for (int it = 0; it < User[currentID - 1].contact.size(); it++) {
            userId = User[currentID - 1].contact[it].second;
            User[userId - 1].recipientquestions.push_back(m1);
        }
        QMessageBox::critical(this, "Waw", "Your question was sent successfully",
            QMessageBox::Ok);
    }

}
//view all sentQuestion
void MainWindow::on_tabWidget_4_tabBarClicked(int index)
{
    QString j = {};
    for (int i = User[currentID - 1].sentquestions.size() - 1; i >= 0; i--) {
        j += User[currentID - 1].sentquestions[i] + "\n";
    }
        ui->label_9->setText(j);
    
}
//edit//
void MainWindow::on_tabWidget_7_tabBarClicked(int index)
{
    //view all recipient Question
    QString a = {};
    if (User[currentID-1].recipientquestions.size() == 0)
    {
        ui->label_11->setText("you don't have any recipient questions");
    }
    else
    {
        for (int i = User[currentID - 1].recipientquestions.size() - 1; i >= 0; i--)
        {
            a += QString::number(User[currentID - 1].recipientquestions[i].id_user) + "\n" + User[currentID - 1].recipientquestions[i].message + "\n";
        }
            ui->label_11->setText(a);
    }
    //view all sentmessage
    QString iduser = {};
    if (User[currentID - 1].sentmessage.size() == 0)
    {
        ui->label_13->setText("You Did not send any messages yet");
    }
    else
    {
        for (QString i : User[currentID - 1].sentmessage)
        {
            iduser += i+"\n";
        }
         ui->label_13->setText(iduser);
    }
}
//view all favorite
void MainWindow::on_tabWidget_2_tabBarClicked(int index)
{
    QString w = {}, m = {};
    if (User[currentID - 1].recipientmessage.size() == 0)
         ui->label_16->setText("Sorry you do not have any message to put in favorite list");
    else {
        for (int i = 0; i < User[currentID - 1].recipientmessage.size(); i++) {
            w = QString::number(i + 1) + "- " + User[currentID - 1].recipientmessage[i].message + "\n";
        }
        ui->label_16->setText(w);
    }
    if (User[currentID - 1].favoritmessage.empty() == true)
        ui->label_18->setText("YOU DO NOT HAVE ANY FAVORATE MESSAGE");
    else
    {
        for (int it = 0; it < User[currentID - 1].favoritmessage.size(); it++) {
            m += QString::number(User[currentID - 1].favoritmessage[it].first) + "\t" + User[currentID - 1].favoritmessage[it].second + "\n";
        }
            ui->label_18->setText(m);
    }
}
// add to favo
void MainWindow::on_pushButton_12_clicked()
{
    if (User[currentID - 1].recipientmessage.size() == 0) {
        QMessageBox::critical(this, "Sorry", "you do not have any message to put in favorite list",
            QMessageBox::Ok);
    }
    else {
        int idmess;
        QString x = ui->lineEdit_5->text();
        idmess = x.toInt();
        if (idmess <= 0 && idmess > User[currentID - 1].recipientmessage.size())
        {
            QMessageBox::critical(this, "Warning", "This number is wrong",
                QMessageBox::Ok);
        }
        else {
            bool favo = false;
            for (int it = 0; it < User[currentID - 1].favoritmessage.size(); it++) {
                if (idmess == User[currentID - 1].favoritmessage[it].first) {
                    QMessageBox::critical(this, "Warning", "This message was added already",
                        QMessageBox::Ok);
                    favo = true;
                }
            }
            idmess--;
            if (favo == false)
            {
                for (int i = 0; i < User[currentID - 1].recipientmessage.size(); i++) {

                    if (idmess == i) {
                        User[currentID - 1].favoritmessage.push_back(make_pair(i + 1, User[currentID - 1].recipientmessage[i].message));
                    }
                }
            }
            QMessageBox::critical(this, "Waw", "your message added successfully",
                QMessageBox::Ok);
        }
    }
}
// remove favorite
void MainWindow::on_pushButton_13_clicked()
{
    if (User[currentID - 1].favoritmessage.empty() == true) {
        QMessageBox::critical(this, "Warning", "YOU DO NOT HAVE ANY FAVORATE MESSAGE",
            QMessageBox::Ok);
    }
    else {
        User[currentID - 1].favoritmessage.erase(User[currentID - 1].favoritmessage.begin());
        QMessageBox::critical(this, "success", " MESSAGE DELETED",
            QMessageBox::Ok);
    }
}
//Undo_qeustion
void MainWindow::on_pushButton_9_clicked()
{
    User[currentID - 1].sentquestions.pop_back();
    int userId;
    for (int it = 0; it < User[currentID - 1].contact.size(); it++) {
        userId = User[currentID - 1].contact[it].second;
        for (int j = User[userId - 1].recipientquestions.size() - 1; j >= 0; j--) {
            if (User[userId - 1].recipientquestions[j].id_user == currentID)
                User[userId - 1].recipientquestions.erase(User[userId - 1].recipientquestions.begin() + j);
        }
    }
    QMessageBox::critical(this, "Wow", "Your question was deleted successfully",
        QMessageBox::Ok);
}

void MainWindow::on_pushButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_pushButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
}
    //view all contact
void MainWindow::on_pushButton_4_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    if (User[currentID - 1].contact.size() == 0)
    {
        ui->label_22->setText("You do not have contacts");
    }
    else
    {
        QString r = {};
        for (int it = 0; it < User[currentID - 1].contact.size(); it++) {
            r += "user id: "+QString::number(User[currentID - 1].contact[it].second) + " ,number of message: " + QString::number(User[currentID - 1].contact[it].first) + "\n";
        }
                ui->label_22->setText(r);
    }
}

void MainWindow::on_pushButton_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}

void MainWindow::on_pushButton_7_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}
//send mess1
void MainWindow::on_pushButton_10_clicked()
{
    int id_message;
    bool is_found = false;
    QString a = ui->lineEdit_2->text();
    id_pushButton_10 = a.toInt();
    for (int i = 0; i < User.size(); i++) {
        for (int k = 0; k < User[i].recipientquestions.size(); k++) {
            if (id_pushButton_10 == User[i].recipientquestions[k].id_user)
            {
                is_found = true;
                break;
            }
        }
    }
    if (is_found && (User[id_pushButton_10].sentquestions.size() == 0))
    {
        ui->label_23->setText("User Is Found But Has No Questions");
    }
    else if (is_found)
    {
        int i = 0;
        QString m = {};
        while (i < User[currentID - 1].recipientquestions.size())
        {
            if (User[currentID - 1].recipientquestions[i].id_user == id_pushButton_10) //check if user found in send him message
            {
                id_message = User[currentID - 1].recipientquestions[i].id_messsage;
                m += QString::number(id_message + 1) + "- " + User[currentID - 1].recipientquestions[i].message + "\n";
            }
            ui->label_23->setText(m); //Display Questins & their ids.
            i++;
        }
        ui->stackedWidget_2->setCurrentIndex(1);
    }
    else
    {
        ui->label_23->setText("User Is n't Found.");
    }
    
}
//view recipient mess
void MainWindow::on_pushButton_18_clicked() {
    // will be edited
    QString z = ui->lineEdit_9->text();
    int userId = z.toInt();
    bool foundUser = false;
    
    foundUser = SearchAboutContact(userId);
    
    if (!foundUser)
    {
        ui->label_15->setText("this id isn't exist in your contact");
    }
    else
    {
        int idQues;
        for (int i = 0; i < User[currentID - 1].recipientmessage.size(); i++) {
            if (User[currentID - 1].recipientmessage[i].id_user == userId) {
                idQues = User[currentID - 1].recipientmessage[i].id_messsage;
                ui->label_15->setText(User[currentID - 1].sentquestions[idQues] + "\n" + z + "  " + User[currentID - 1].recipientmessage[i].message + "\n");
            }
        }
    }
   
}
//remove contact
void MainWindow::on_pushButton_15_clicked()
{//remove contact
    if (User[currentID - 1].contact.size() == 0)
    {
        QMessageBox::critical(this, "sorry", "you do not have any contacts",
            QMessageBox::Ok);
    }
    else
    {
        QString p = ui->lineEdit_7->text();
        int cnt_id = p.toInt();
        bool found_id = false;

        for(int it = 0; it < User[currentID - 1].contact.size(); it++){
            if (User[currentID - 1].contact[it].second == cnt_id)
            {
                User[currentID - 1].contact.erase(User[currentID - 1].contact.begin() + it);
                found_id = true;
            }

        }
        if (found_id)
        {
            QMessageBox::critical(this, "ohhh", "Contact has been removed successfully",
                QMessageBox::Ok);
        }
        else
        {
            QMessageBox::critical(this, "sorry", "invalid contact id",
                QMessageBox::Ok);
        }
    }
    
}
//send mess2
void MainWindow::on_pushButton_16_clicked() {
    Sentmessages w;
    int numofmes;
    QString z = ui->lineEdit_3->text();
    w.id_messsage = z.toInt();
    w.id_messsage--;
    bool isfound_id_messsage = false;
    for (int i = 0; i < User[currentID - 1].recipientquestions.size(); i++)
    {
        if (w.id_messsage == User[currentID - 1].recipientquestions[i].id_messsage)
        {
            isfound_id_messsage = true;
            break;
        }
    }
    if (isfound_id_messsage)
    {
        w.message = ui->lineEdit_8->text();
       
        w.id_user = currentID;
        User[id_pushButton_10 - 1].recipientmessage.push_back(w);//answer,id_user_answer,id_question.
        User[currentID - 1].sentmessage.push_back(w.message);//answer.

        for (int it = 0; it < User[id_pushButton_10 - 1].contact.size(); it++) {
            if (User[id_pushButton_10 - 1].contact[it].second == currentID) {
                numofmes = User[id_pushButton_10 - 1].contact[it].first + 1;
                User[id_pushButton_10 - 1].contact.erase(User[id_pushButton_10 - 1].contact.begin() + it);
                User[id_pushButton_10 - 1].contact.push_back(make_pair(numofmes, currentID));
                break;
            }
        }
        QMessageBox::critical(this, "ohh", "Your Message has sent Successfully",
            QMessageBox::Ok);
    }
    else
    {
        QMessageBox::critical(this, "Sorry", "Invalid Id_question,Please choose From the list!!",
            QMessageBox::Ok);
    }

}
    //add contact
void MainWindow::on_pushButton_14_clicked()
{ 
    bool found_recipient_mes = false, found_recipient_que = false, found_contact = false;
    QString p = ui->lineEdit_6->text();
    int senderid = p.toInt();
    for (int i = 0; i < User[currentID - 1].recipientmessage.size(); i++) {
        if (User[currentID - 1].recipientmessage[i].id_user == senderid)
        {
            found_recipient_mes = true;
            found_contact = SearchAboutContact(senderid);
            break;
        }
    }
    for (int i = 0; i < User[currentID - 1].recipientquestions.size(); i++) {
        if (User[currentID - 1].recipientquestions[i].id_user == senderid)
        {
            found_recipient_que = true;
            found_contact = SearchAboutContact(senderid);
            break;
        }
    }
    if ((found_recipient_mes && found_contact) || (found_recipient_que && found_contact)) {
        QMessageBox::critical(this, "sorry", "this user is existed in your contact",
            QMessageBox::Ok);
    }
    else if (found_recipient_mes && (!found_contact)) {
        User[currentID-1].contact.push_back(make_pair(1, senderid));
        QMessageBox::critical(this, "ohh", "this user added successfully",
            QMessageBox::Ok);
    }
    else if (found_recipient_que && (!found_contact)) {
        User[currentID - 1].contact.push_back(make_pair(0, senderid));
        QMessageBox::critical(this, "ohh", "this user added successfully",
            QMessageBox::Ok);
    }
    else {
         QMessageBox::critical(this, "sorry", "this user did not send you a message",
                    QMessageBox::Ok);
    }
  
}
//undo mess
void MainWindow::on_pushButton_11_clicked() {
    int current_Index = 0;
    int id; int numofmes;
    bool is_found = false, is_found_person = false;
    if (User[currentID - 1].sentmessage.size() == 0)
    {
        QMessageBox::critical(this, "Sorry", "There Are No Messages To Undo",
            QMessageBox::Ok);
    }
    else if (User[currentID - 1].sentmessage.size() != 0)
    {
        QString w = ui->lineEdit_4->text();
        id = w.toInt();
        for (int k = 0; k < User[currentID - 1].recipientquestions.size(); k++) {
            if (id == User[currentID - 1].recipientquestions[k].id_user) {
                current_Index = 1;
                break;
            }
        }
        if (current_Index) {
            for (int j = User[id - 1].recipientmessage.size() - 1; j >= 0; j--)
            {
                if ((currentID == User[id - 1].recipientmessage[j].id_user) && (User[currentID - 1].sentmessage.back() == User[id - 1].recipientmessage[j].message))
                {
                    User[id - 1].recipientmessage.erase(User[id - 1].recipientmessage.begin() + j);
                    User[currentID - 1].sentmessage.pop_back();
                    for (int it = 0; it < User[id - 1].contact.size(); it++) {
                        if (User[id - 1].contact[it].second == currentID) {
                            numofmes = User[id - 1].contact[it].first - 1;
                            User[id - 1].contact.erase(User[id - 1].contact.begin() + it);
                            User[id - 1].contact.push_back(make_pair(numofmes, currentID));
                            break;
                        }
                    }
                    QMessageBox::critical(this, "ohh", "The message deleted Successfully",
                        QMessageBox::Ok);
                    is_found = true;
                    break;
                }
            }
        }
        else
        {
            QMessageBox::critical(this, "Sorry", "This Person Not found",
                QMessageBox::Ok);
        }
        if (!is_found && current_Index)
        {
            QMessageBox::critical(this, "Sorry", "This Person Not has your message",
                QMessageBox::Ok);
        }
    }
}

bool MainWindow::SearchAboutContact(int sender_id)
{
    for (int it = 0; it < User[currentID - 1].contact.size(); it++) {
        if (User[currentID - 1].contact[it].second == sender_id)
        {
            return true;
        }
    }
    return false;
}

void MainWindow::read1()
{
    user u1;
    QString id_user, id_mes, mes, seperator, fav;
    int iduser, idmes;
    Sentmessages sent_mes;
    QFile file("user.txt");
    QFile contacts("contact.txt");
    QFile recipientques("recipientques.txt");
    QFile recipientmes("recipientmes.txt");
    QFile favoritemes("favoritemes.txt");


    if (file.open(QIODevice::ReadOnly)) {
        QTextStream fi(&file);
        for (int i = 0; !fi.atEnd(); i++) {
            id_user = fi.readLine();
            u1.username = fi.readLine();
            u1.password = fi.readLine();
            u1.id = id_user.toInt();
            User.push_back(u1);
        }
    }

    contacts.open(QIODevice::ReadOnly);
    QTextStream con(&contacts);
    for (int i = 0; i < User.size(); i++) {
        while (true) {
            id_mes = con.readLine();
            id_user = con.readLine();
            seperator = con.readLine();
            idmes = id_mes.toInt();
            iduser = id_user.toInt();
            User[i].contact.push_back(make_pair(idmes, iduser));
            if (seperator == "+")
                break;
        }
        sort(User[i].contact.begin(), User[i].contact.end());
    }
    favoritemes.open(QIODevice::ReadOnly);
    QTextStream favoritemess(&favoritemes);
    for (int i = 0; i < User.size(); i++) {
        while (true) {
            id_mes = favoritemess.readLine();
            mes = favoritemess.readLine();
            seperator = favoritemess.readLine();
            idmes = id_mes.toInt();
            User[i].favoritmessage.push_back(make_pair(idmes, mes));
            if (seperator == "+") { // - anther message ,//+ anther user
                break;
            }
        }
    }
    recipientques.open(QIODevice::ReadOnly);
    QTextStream stream(&recipientques);
    for (int i = 0; i < User.size(); i++) {
        for (int j = 0; !stream.atEnd(); j++) {
            id_user = stream.readLine();
            id_mes = stream.readLine();
            sent_mes.message = stream.readLine();
            seperator = stream.readLine();
            sent_mes.id_user = id_user.toInt();
            sent_mes.id_messsage = id_mes.toInt();
            User[i].recipientquestions.push_back(sent_mes);
            User[sent_mes.id_user - 1].sentquestions.push_back(sent_mes.message);
            if (stream.atEnd()) { break; }
            if (seperator == "+") { // - anther message ,//+ anther user
                break;
            }
        }
    }
    recipientmes.open(QIODevice::ReadOnly);
    QTextStream recipientmess(&recipientmes);
    for (int i = 0; i < User.size(); i++) {
        for (int j = 0; !recipientmess.atEnd(); j++) {
            id_user = recipientmess.readLine();
            id_mes = recipientmess.readLine();
            sent_mes.message = recipientmess.readLine();
            seperator = recipientmess.readLine();
            sent_mes.id_user = id_user.toInt();
            sent_mes.id_messsage = id_mes.toInt();
            User[i].recipientmessage.push_back(sent_mes);
            User[sent_mes.id_user - 1].sentmessage.push_back(sent_mes.message);
            if (recipientmess.atEnd()) { break; }
            if (seperator == "+") { // - anther message ,//+ anther user
                break;
            }
        }
    }

    file.close();
    contacts.close();
    recipientques.close();
    recipientmes.close();
    favoritemes.close();
}
//log out
void MainWindow::store1()
{
    /*
        store all data in the files
    */
    QString mes, iduser, idmes;
    QFile file("user.txt");
    QFile contacts("contact.txt");
    QFile recipientques("recipientques.txt");
    QFile recipientmes("recipientmes.txt");
    QFile fevoritemes("favoritemes.txt");

    file.open(QIODevice::WriteOnly);
    QTextStream in(&file);
    for (int i = 0; i < User.size(); i++)
    {
        in << QString::number(User[i].id) << "\n" << User[i].username << "\n" << User[i].password;
        if (i == User.size() - 1)
            break;
        in << "\n";
    }

    for (int i = 0; i < User.size(); i++)
    {
        contacts.open(QIODevice::WriteOnly);
        QTextStream cont(&contacts);
        for (int j = 0; j < User[i].contact.size(); j++)
        {
            cont << User[i].contact[j].first << "\n" << User[i].contact[j].second << "\n";
            if (j + 1 == User[i].contact.size()) {
                cont << "+";
                if (i == User.size() - 1)
                    break;
            }
            else { cont << "-"; }
            cont << "\n";
        }

        fevoritemes.open(QIODevice::WriteOnly);
        QTextStream fev(&fevoritemes);
        for (int j = 0; j < User[i].favoritmessage.size(); j++)
        {
            fev << User[i].favoritmessage[j].first << "\n" << User[i].favoritmessage[j].second << "\n";
            if (j + 1 == User[i].favoritmessage.size()) {
                fev << "+";
                if (i == User.size() - 1)
                    break;
            }
            else { fev << "-"; }
            fev << "\n";

        }
        recipientques.open(QIODevice::WriteOnly);
        QTextStream requ(&recipientques);
        for (int j = 0; j < User[i].recipientquestions.size(); j++)
        {
            requ << User[i].recipientquestions[j].id_user << "\n" << User[i].recipientquestions[j].id_messsage << "\n" << User[i].recipientquestions[j].message << "\n";
            if (j + 1 == User[i].recipientquestions.size()) {
                requ << "+";
                if (i == User.size() - 1)
                    break;
            }
            else { requ << "-"; }
            requ << "\n";
        }

        recipientmes.open(QIODevice::WriteOnly);
        QTextStream reme(&recipientmes);
        for (int j = 0; j < User[i].recipientmessage.size(); j++)
        {
            reme << User[i].recipientmessage[j].id_user << "\n" << User[i].recipientmessage[j].id_messsage << "\n" << User[i].recipientmessage[j].message << "\n";
            if (j + 1 == User[i].recipientmessage.size()) {
                reme << "+";
                if (i == User.size() - 1)
                    break;
            }
            else { reme << "-"; }
            reme << "\n";
        }

    }

    fevoritemes.close();
    file.close();
    contacts.close();
    recipientques.close();
    recipientmes.close();
}

void MainWindow::on_pushButton_5_clicked()
{
    store1();
    close();
}