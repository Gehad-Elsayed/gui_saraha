#pragma once
#include <QDialog>
#include "ui_log_in.h"
#include"mainwindow.h"
#include "user.h"
namespace Ui {
    class log_in;
}

class log_in : public QDialog
{
    Q_OBJECT

public:
    explicit log_in(QWidget* parent = nullptr);
    ~log_in();
    QVector<user> User;
    int id_user = 0;
private slots:
    void on_pushButton_2_clicked();
    void on_pushButton_clicked();

private:
    Ui::log_in* ui;
    MainWindow* ma;
    void read();
    void store();
};

