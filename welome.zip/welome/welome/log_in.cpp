#include "log_in.h"
#include <iostream>
#include <QString>
#include <QMessageBox>
#include <assert.h>
#include<QFile.h>
#include <QFile>            /// read and write 
#include <iostream>
#include<QVector>
#include<qcoreapplication>
#include<qtextstream>
#include <QDataStream>
using namespace std;
log_in::log_in(QWidget *parent) :
    QDialog(parent)
    , ui(new Ui::log_in)
{
    ui->setupUi(this);
	read();
}

log_in::~log_in()
{
    delete ui;
}
//sign up
void log_in::on_pushButton_2_clicked()
{
	if (User.size() == 0) {
		id_user = 1;
	}
	else {
		id_user = User[User.size() - 1].id + 1;
	}
	QString username = {}, password = {}, rewritePassword = {};
	username = ui->lineEdit_7->text();
	password = ui->lineEdit_6->text();
	rewritePassword = ui->lineEdit_5->text();
	if (username.isEmpty()|| password.isEmpty() || rewritePassword.isEmpty()) {
		QMessageBox::critical(this, "Erorr", "please compelete all fields",
			QMessageBox::Ok);
	}
	else {
		if (password != rewritePassword) {
			QMessageBox::critical(this, "Erorr", "password and confirm not match",
				QMessageBox::Ok);
		}
		else {
			user u(id_user, username, password);
			User.push_back(u);

			QString ques;
			ques = "Hello, do you want to send me a message?";
			User[id_user - 1].sentquestions.push_back(ques);
			Sentmessages m1;
			m1.message = ques;
			m1.id_messsage = 0;
			m1.id_user = id_user;
			for (int i = 0; i < User.size(); i++) {
				if (i == (id_user - 1))
					continue;
				User[i].recipientquestions.push_back(m1);
			}

			ma = new MainWindow(this);
			//ma->currentID = id_user;
			ma->show();
		}
		//store();
		close();
	}
}

//log in
void log_in::on_pushButton_clicked()
{
	
	bool foundUser = false;
	char ch = {};
	QString username, password;
	username = ui->lineEdit->text();
	password = ui->lineEdit_2->text();
	for (int i = 0; i < User.size(); i++) {
		if ((User[i].username == username) && (User[i].password == password)) {
			foundUser = true;
			id_user = i + 1;
			break;
		}
	}
	if (foundUser) {
		QMessageBox::critical(this, "Waw", "Successful LOGIN",
			QMessageBox::Ok);
		//MainWindow* ma;
		//ma->currentID = id_user;
		ma = new MainWindow(this);
		ma->show();
	}
	else
	{
		QMessageBox::critical(this, "Sorry", "username or password is wrong!!, please try again",
			QMessageBox::Ok);
	}
    close();
}

void log_in::read()
{
	user u1;
	QString id_user, id_mes, mes, seperator, fav;
	int iduser, idmes;
	Sentmessages sent_mes;
	QFile file("user.txt");
	QFile contacts("contact.txt");
	QFile recipientques("recipientques.txt");
	QFile recipientmes("recipientmes.txt");
	QFile favoritemes("favoritemes.txt");


	if (file.open(QIODevice::ReadOnly)) {
		QTextStream fi(&file);
		for (int i = 0; !fi.atEnd(); i++) {
			id_user = fi.readLine();
			u1.username = fi.readLine();
			u1.password = fi.readLine();
			u1.id = id_user.toInt();
			User.push_back(u1);
		}
	}

	contacts.open(QIODevice::ReadOnly);
	QTextStream con(&contacts);
	for (int i = 0; i < User.size(); i++) {
		while (true) {
			id_mes = con.readLine();
			id_user = con.readLine();
			seperator = con.readLine();
			idmes = id_mes.toInt();
			iduser = id_user.toInt();
			User[i].contact.push_back(make_pair(idmes, iduser));
			if (seperator == "+")
				break;
		}
		sort(User[i].contact.begin(), User[i].contact.end());
	}
	favoritemes.open(QIODevice::ReadOnly);
	QTextStream favoritemess(&favoritemes);
	for (int i = 0; i < User.size(); i++) {
		while (true) {
			id_mes = favoritemess.readLine();
			mes = favoritemess.readLine();
			seperator = favoritemess.readLine();
			idmes = id_mes.toInt();
			User[i].favoritmessage.push_back(make_pair(idmes, mes));
			if (seperator == "+") { // - anther message ,//+ anther user
				break;
			}
		}
	}
	recipientques.open(QIODevice::ReadOnly);
	QTextStream stream(&recipientques);
	for (int i = 0; i < User.size(); i++) {
		for (int j = 0; !stream.atEnd(); j++) {
			id_user = stream.readLine();
			id_mes = stream.readLine();
			sent_mes.message = stream.readLine();
			seperator = stream.readLine();
			sent_mes.id_user = id_user.toInt();
			sent_mes.id_messsage = id_mes.toInt();
			User[i].recipientquestions.push_back(sent_mes);
			User[sent_mes.id_user - 1].sentquestions.push_back(sent_mes.message);
			if (stream.atEnd()) { break; }
			if (seperator == "+") { // - anther message ,//+ anther user
				break;
			}
		}
	}
	recipientmes.open(QIODevice::ReadOnly);
	QTextStream recipientmess(&recipientmes);
	for (int i = 0; i < User.size(); i++) {
		for (int j = 0; !recipientmess.atEnd(); j++) {
			id_user = recipientmess.readLine();
			id_mes = recipientmess.readLine();
			sent_mes.message = recipientmess.readLine();
			seperator = recipientmess.readLine();
			sent_mes.id_user = id_user.toInt();
			sent_mes.id_messsage = id_mes.toInt();
			User[i].recipientmessage.push_back(sent_mes);
			User[sent_mes.id_user - 1].sentmessage.push_back(sent_mes.message);
			if (recipientmess.atEnd()) { break; }
			if (seperator == "+") { // - anther message ,//+ anther user
				break;
			}
		}
	}

	file.close();
	contacts.close();
	recipientques.close();
	recipientmes.close();
	favoritemes.close();
}

void log_in::store()
{
	QString mes, iduser, idmes;
	QFile file("user.txt");
	QFile contacts("contact.txt");
	QFile recipientques("recipientques.txt");
	QFile recipientmes("recipientmes.txt");
	QFile fevoritemes("favoritemes.txt");

	file.open(QIODevice::WriteOnly);
	QTextStream in(&file);
	for (int i = 0; i < User.size(); i++)
	{
		in << QString::number(User[i].id) << "\n" << User[i].username << "\n" << User[i].password;
		if (i == User.size() - 1)
			break;
		in << "\n";
	}

	for (int i = 0; i < User.size(); i++)
	{
		contacts.open(QIODevice::WriteOnly);
		QTextStream cont(&contacts);
		for (int j = 0; j < User[i].contact.size(); j++)
		{
			cont << User[i].contact[j].first << "\n" << User[i].contact[j].second << "\n";
			if (j + 1 == User[i].contact.size()) {
				cont << "+";
				if (i == User.size() - 1)
					break;
			}
			else { in << "-"; }
			cont << "\n";
		}

		fevoritemes.open(QIODevice::WriteOnly);
		QTextStream fev(&fevoritemes);
		for (int j = 0; j < User[i].favoritmessage.size(); j++)
		{
			fev << User[i].favoritmessage[j].first << "\n" << User[i].favoritmessage[j].second << "\n";
			if (j + 1 == User[i].favoritmessage.size()) {
				fev << "+";
				if (i == User.size() - 1)
					break;
			}
			else { fev << "-"; }
			fev << "\n";

		}
		recipientques.open(QIODevice::WriteOnly);
		QTextStream requ(&recipientques);
		for (int j = 0; j < User[i].recipientquestions.size(); j++)
		{
			requ << User[i].recipientquestions[j].id_user << "\n" << User[i].recipientquestions[j].id_messsage << "\n" << User[i].recipientquestions[j].message << "\n";
			if (j + 1 == User[i].recipientquestions.size()) {
				requ << "+";
				if (i == User.size() - 1)
					break;
			}
			else { requ << "-"; }
			requ << "\n";
		}

		recipientmes.open(QIODevice::WriteOnly);
		QTextStream reme(&recipientmes);
		for (int j = 0; j < User[i].recipientmessage.size(); j++)
		{
			reme << User[i].recipientmessage[j].id_user << "\n" << User[i].recipientmessage[j].id_messsage << "\n" << User[i].recipientmessage[j].message << "\n";
			if (j + 1 == User[i].recipientmessage.size()) {
				reme << "+";
				if (i == User.size() - 1)
					break;
			}
			else { reme << "-"; }
			reme << "\n";
		}

	}

	fevoritemes.close();
	file.close();
	contacts.close();
	recipientques.close();
	recipientmes.close();
}

