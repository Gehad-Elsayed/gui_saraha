#pragma once
#include<QVector>
#include<QList>
#include<iostream>
#include<unordered_map>
#include<map>
#include <QString>
using namespace std;
class Sentmessages {
public:
	int id_user, id_messsage;
	QString message;
	Sentmessages();
};
class user
{
public:
	int id;
	QString username, password;
	QVector < std::pair<int, int>> contact;
	QList<QString> sentmessage;
	QVector < std::pair<int, QString>> favoritmessage;
	QVector<Sentmessages> recipientmessage;
	QVector<QString> sentquestions; // send quetion to ids which i have in my contacts
	QVector<Sentmessages> recipientquestions;
	user();
	~user();
	user(int id, QString username, QString password);
};