#include "welome.h"
#include "mainwindow.h"
#include <QtWidgets/QApplication>
#include "site.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //site s;
    welome w;
    w.show();
    /*MainWindow ma;
    ma.show();*/
    return a.exec();
}
