//#include "site.h"
//#include <string>    // ctrl r
//#include <conio.h> //getline
//#include <fstream>            /// read and write 
//#include <QFile>            /// read and write 
//#include <iostream>
//#include <assert.h>
//#include<QFile.h>
//#include<fstream>
//#include<QString>
//#include<Qvector>
//#include<QMessageBox>
//#include<iostream>
//#include<qcoreapplication>
//#include<qtextstream>
//#include <QDataStream>
//#include "mainwindow.h"
////#include<Windows.h>  //for edit console
//using namespace std;
//
////ok
//site::site()
//{
//	read();
//}
////ok
//void site::read()
//{
//	/*
//		read all data from the files
//	*/
//	user u1;
//	QString id_user, id_mes, mes, seperator, fav;
//	int iduser, idmes;
//	Sentmessages sent_mes;
//	QFile file("user.txt");
//	QFile contacts("contact.txt");
//	QFile recipientques("recipientques.txt");
//	QFile recipientmes("recipientmes.txt");
//	QFile favoritemes("favoritemes.txt");
//
//
//	if (file.open(QIODevice::ReadOnly)) {
//		QTextStream fi(&file);
//		for (int i = 0; !fi.atEnd(); i++) {
//			id_user = fi.readLine();
//			u1.username = fi.readLine();
//			u1.password = fi.readLine();
//			u1.id = id_user.toInt();
//			User.push_back(u1);
//		}
//	}
//
//	contacts.open(QIODevice::ReadOnly);
//	QTextStream con(&contacts);
//	for (int i = 0; i < User.size(); i++) {
//		while (true) {
//			id_mes = con.readLine();
//			id_user = con.readLine();
//			seperator = con.readLine();
//			idmes = id_mes.toInt();
//			iduser = id_user.toInt();
//			User[i].contact.push_back(make_pair(idmes, iduser));
//			if (seperator == "+")
//				break;
//		}
//		sort(User[i].contact.begin(), User[i].contact.end());
//	}
//	favoritemes.open(QIODevice::ReadOnly);
//	QTextStream favoritemess(&favoritemes);
//	for (int i = 0; i < User.size(); i++) {
//		while (true) {
//			id_mes = favoritemess.readLine();
//			mes = favoritemess.readLine();
//			seperator = favoritemess.readLine();
//			idmes = id_mes.toInt();
//			User[i].favoritmessage.push_back(make_pair(idmes, mes));
//			if (seperator == "+") { // - anther message ,//+ anther user
//				break;
//			}
//		}
//	}
//	recipientques.open(QIODevice::ReadOnly);
//	QTextStream stream(&recipientques);
//	for (int i = 0; i < User.size(); i++) {
//		for (int j = 0; !stream.atEnd(); j++) {
//			id_user = stream.readLine();
//			id_mes = stream.readLine();
//			sent_mes.message = stream.readLine();
//			seperator = stream.readLine();
//			sent_mes.id_user = id_user.toInt();
//			sent_mes.id_messsage = id_mes.toInt();
//			User[i].recipientquestions.push_back(sent_mes);
//			User[sent_mes.id_user - 1].sentquestions.push_back(sent_mes.message);
//			if (stream.atEnd()) { break; }
//			if (seperator == "+") { // - anther message ,//+ anther user
//				break;
//			}
//		}
//	}
//	recipientmes.open(QIODevice::ReadOnly);
//	QTextStream recipientmess(&recipientmes);
//	for (int i = 0; i < User.size(); i++) {
//		for (int j = 0; !recipientmess.atEnd(); j++) {
//			id_user = recipientmess.readLine();
//			id_mes = recipientmess.readLine();
//			sent_mes.message = recipientmess.readLine();
//			seperator = recipientmess.readLine();
//			sent_mes.id_user = id_user.toInt();
//			sent_mes.id_messsage = id_mes.toInt();
//			User[i].recipientmessage.push_back(sent_mes);
//			User[sent_mes.id_user - 1].sentmessage.push_back(sent_mes.message);
//			if (recipientmess.atEnd()) { break; }
//			if (seperator == "+") { // - anther message ,//+ anther user
//				break;
//			}
//		}
//	}
//
//	file.close();
//	contacts.close();
//	recipientques.close();
//	recipientmes.close();
//	favoritemes.close();
//}
////ok
//void site::store()
//{
//	/*
//		store all data in the files
//	*/
//	QString mes, iduser, idmes;
//	QFile file("user.txt");
//	QFile contacts("contact.txt");
//	QFile recipientques("recipientques.txt");
//	QFile recipientmes("recipientmes.txt");
//	QFile fevoritemes("favoritemes.txt");
//
//	file.open(QIODevice::WriteOnly);
//	QTextStream in(&file);
//	for (int i = 0; i < User.size(); i++)
//	{
//		in << QString::number(User[i].id) << "\n" << User[i].username << "\n" << User[i].password;
//		if (i == User.size() - 1)
//			break;
//		in << "\n";
//	}
//
//	for (int i = 0; i < User.size(); i++)
//	{
//		contacts.open(QIODevice::WriteOnly);
//		QTextStream cont(&contacts);
//		for (int j = 0; j < User[i].contact.size(); j++)
//		{
//			cont << User[i].contact[j].first << "\n" << User[i].contact[j].second << "\n";
//			if (j + 1 == User[i].contact.size()) {
//				cont << "+";
//				if (i == User.size() - 1)
//					break;
//			}
//			else { in << "-"; }
//			cont << "\n";
//		}
//
//		fevoritemes.open(QIODevice::WriteOnly);
//		QTextStream fev(&fevoritemes);
//		for (int j = 0; j < User[i].favoritmessage.size(); j++)
//		{
//			fev << User[i].favoritmessage[j].first << "\n" << User[i].favoritmessage[j].second << "\n";
//			if (j + 1 == User[i].favoritmessage.size()) {
//				fev << "+";
//				if (i == User.size() - 1)
//					break;
//			}
//			else { fev << "-"; }
//			fev << "\n";
//
//		}
//		recipientques.open(QIODevice::WriteOnly);
//		QTextStream requ(&recipientques);
//		for (int j = 0; j < User[i].recipientquestions.size(); j++)
//		{
//			requ << User[i].recipientquestions[j].id_user << "\n" << User[i].recipientquestions[j].id_messsage << "\n" << User[i].recipientquestions[j].message << "\n";
//			if (j + 1 == User[i].recipientquestions.size()) {
//				requ << "+";
//				if (i == User.size() - 1)
//					break;
//			}
//			else { requ << "-"; }
//			requ << "\n";
//		}
//
//		recipientmes.open(QIODevice::WriteOnly);
//		QTextStream reme(&recipientmes);
//		for (int j = 0; j < User[i].recipientmessage.size(); j++)
//		{
//			reme << User[i].recipientmessage[j].id_user << "\n" << User[i].recipientmessage[j].id_messsage << "\n" << User[i].recipientmessage[j].message << "\n";
//			if (j + 1 == User[i].recipientmessage.size()) {
//				reme << "+";
//				if (i == User.size() - 1)
//					break;
//			}
//			else { reme << "-"; }
//			reme << "\n";
//		}
//
//	}
//
//	fevoritemes.close();
//	file.close();
//	contacts.close();
//	recipientques.close();
//	recipientmes.close();
//}
//
//void site::SendMessageToAllUsers()
//{///////
//	QString ques;
//	ques = "Hello, do you want to send me a message?";
//	User[id_user - 1].sentquestions.push_back(ques);
//	Sentmessages m1;
//	m1.message = ques;
//	m1.id_messsage = 0;
//	m1.id_user = id_user;
//	for (int i = 0; i < User.size(); i++) {
//		if (i == (id_user - 1))
//			continue;
//		User[i].recipientquestions.push_back(m1);
//	}
//}
////ok**********
//void site::Send_Qestion(QString ques)
//{////
//	User[id_user - 1].sentquestions.push_back(ques);
//	Sentmessages m1;
//	m1.message = ques;
//	m1.id_messsage = User[id_user - 1].sentquestions.size() - 1;
//
//	m1.id_user = id_user;
//	if (User[id_user - 1].contact.size() == 0)
//	{
//		QMessageBox msgBox;
//		msgBox.setWindowTitle("Warning");
//		msgBox.setText("you do not have any recipient");
//		msgBox.setStandardButtons(QMessageBox::Ok);
//		msgBox.setDefaultButton(QMessageBox::Ok);
//		//if (msgBox.exec() == QMessageBox::Ok) {
//		//	// do something
//		//}
//		//else {
//		//	// do something else
//		//}
//	}
//	else {
//		int userId;
//		for (int it = 0; it <User[id_user -1].contact.size(); it++) {
//			userId = User[id_user - 1].contact[it].second;
//			User[userId - 1].recipientquestions.push_back(m1);
//		}
//	}
//}
////ok*********
//void site::Undo_qeustion()
//{
//	User[id_user - 1].sentquestions.pop_back();
//	int userId;
//	for (int it = 0; it < User[id_user - 1].contact.size(); it++) {
//		userId = User[id_user - 1].contact[it].second;
//		for (int j = User[id_user - 1].recipientquestions.size() - 1; j >= 0; j--) {
//			if (User[userId - 1].recipientquestions[j].id_user == id_user)
//				User[userId - 1].recipientquestions.erase(User[userId - 1].recipientquestions.begin() + j);
//		}
//	}
//}
////ok**************
//bool site::SearchAboutContact(int sender_id)
//{
//	for (int it = 0; it < User[id_user - 1].contact.size(); it++) {
//		if (User[id_user - 1].contact[it].second == sender_id)
//		{
//			return true;
//		}
//	}
//	return false;
//}
//
//site::~site()
//{
//	User.clear();
//}

