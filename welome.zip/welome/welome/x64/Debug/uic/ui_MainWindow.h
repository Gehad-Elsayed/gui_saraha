/********************************************************************************
** Form generated from reading UI file 'MainWindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QFrame *frame_2;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_7;
    QPushButton *pushButton_6;
    QPushButton *pushButton_5;
    QFrame *frame;
    QVBoxLayout *verticalLayout_13;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QVBoxLayout *verticalLayout_2;
    QFrame *frame_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QFrame *frame_4;
    QLabel *label_21;
    QLabel *label_22;
    QWidget *page_3;
    QVBoxLayout *verticalLayout_10;
    QFrame *frame_7;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_3;
    QFrame *frame_8;
    QLineEdit *lineEdit_6;
    QPushButton *pushButton_14;
    QWidget *page_5;
    QVBoxLayout *verticalLayout_16;
    QFrame *frame_11;
    QVBoxLayout *verticalLayout_14;
    QLabel *label_5;
    QFrame *frame_12;
    QLineEdit *lineEdit_7;
    QPushButton *pushButton_15;
    QWidget *page_4;
    QVBoxLayout *verticalLayout_17;
    QFrame *frame_9;
    QVBoxLayout *verticalLayout_11;
    QLabel *label_4;
    QFrame *frame_10;
    QVBoxLayout *verticalLayout_12;
    QTabWidget *tabWidget_4;
    QWidget *tab_7;
    QLineEdit *lineEdit;
    QPushButton *pushButton_8;
    QWidget *tab_8;
    QLabel *label_6;
    QPushButton *pushButton_9;
    QWidget *tab_11;
    QLabel *label_8;
    QLabel *label_9;
    QWidget *page_7;
    QVBoxLayout *verticalLayout_22;
    QFrame *frame_15;
    QVBoxLayout *verticalLayout_20;
    QLabel *label_7;
    QFrame *frame_16;
    QVBoxLayout *verticalLayout_21;
    QTabWidget *tabWidget_7;
    QWidget *tab_13;
    QLabel *label_10;
    QLabel *label_11;
    QWidget *tab_14;
    QLineEdit *lineEdit_2;
    QStackedWidget *stackedWidget_2;
    QWidget *page_6;
    QWidget *page_8;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_8;
    QPushButton *pushButton_16;
    QLabel *label_23;
    QPushButton *pushButton_10;
    QWidget *tab_12;
    QLabel *label_12;
    QLabel *label_13;
    QWidget *tab_15;
    QLineEdit *lineEdit_4;
    QPushButton *pushButton_11;
    QLabel *label_14;
    QWidget *page_2;
    QVBoxLayout *verticalLayout_7;
    QFrame *frame_5;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_2;
    QFrame *frame_6;
    QVBoxLayout *verticalLayout_6;
    QTabWidget *tabWidget_2;
    QWidget *tab_3;
    QLabel *label_15;
    QLineEdit *lineEdit_9;
    QPushButton *pushButton_18;
    QWidget *tab_4;
    QLabel *label_16;
    QLineEdit *lineEdit_5;
    QPushButton *pushButton_12;
    QLabel *label_20;
    QWidget *tab_16;
    QLabel *label_17;
    QPushButton *pushButton_13;
    QWidget *tab_17;
    QLabel *label_18;
    QLabel *label_19;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1294, 629);
        MainWindow->setStyleSheet(QString::fromUtf8("/*\n"
"Colour scheme used:\n"
"- White (text): #eff0f1\n"
"- Dark black (main bg): #272a2d\n"
"- Lighter dark black (menu bar): #373b3f\n"
"- Dark blue: #18465d\n"
"- Gray: #76797C\n"
"- Red (accents): #db1c49\n"
"\n"
"Useful reference on QSS:\n"
" - http://doc.qt.io/qt-5/stylesheet-reference.html#alternate-background-color-prop\n"
"\n"
"Be sure to change all image urls to the appropriate folder on your system.\n"
"*/\n"
"\n"
"/*================================================================\n"
"QWidget\n"
"================================================================*/\n"
"*{\n"
"border : 2px  #3daee9   solid ;\n"
"border-radius:5px;\n"
"}\n"
"QWidget {\n"
"	color: #eff0f1;\n"
"	background-color: #272a2d;\n"
"	selection-background-color: #db1c49;\n"
"	selection-color: #eff0f1;\n"
"}\n"
"QLabel{\n"
"border : 1px solid #00a5a5 ;\n"
"}\n"
"QTabWidget{\n"
"border-right  : 1px solid #00a5a5 ;\n"
" border-left :1px solid #00a5a5 ;\n"
"}\n"
"QWidget::item:hover {\n"
"	background-color: #00a5a5 ;\n"
"	color: #eff"
                        "0f1;\n"
"}\n"
"\n"
"QWidget::item:selected {\n"
"	background-color: #00a5a5 ;\n"
"}\n"
"\n"
"/*================================================================\n"
"QCheckBox/QGroupBox\n"
"================================================================*/\n"
"QCheckBox {\n"
"	spacing: 5px;\n"
"	outline: none;\n"
"	color: #eff0f1;\n"
"	margin-bottom: 2px;\n"
"}\n"
"\n"
"QCheckBox:disabled {\n"
"	color: #00a5a5 ;\n"
"}\n"
"\n"
"QCheckBox::indicator,\n"
"QGroupBox::indicator {\n"
"	width: 18px;\n"
"	height: 18px;\n"
"}\n"
"\n"
"QGroupBox::indicator {\n"
"	margin-left: 2px;\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/checkbox_unchecked.png);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked:hover,\n"
"QCheckBox::indicator:unchecked:focus,\n"
"QCheckBox::indicator:unchecked:pressed,\n"
"QGroupBox::indicator:unchecked:hover,\n"
"QGroupBox::indicator:unchecked:focus,\n"
"QGroupBox::indicator:unchecked:pressed {\n"
"	border: none;\n"
"	image: url(C:/Users/user/"
                        "AppData/Roaming/TeXstudio/rc/checkbox_unchecked_focus.png);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/checkbox_checked.png);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked:hover,\n"
"QCheckBox::indicator:checked:focus,\n"
"QCheckBox::indicator:checked:pressed,\n"
"QGroupBox::indicator:checked:hover,\n"
"QGroupBox::indicator:checked:focus,\n"
"QGroupBox::indicator:checked:pressed {\n"
"	border: none;\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/checkbox_checked_focus.png);\n"
"}\n"
"\n"
"QCheckBox::indicator:indeterminate {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/checkbox_indeterminate.png);\n"
"}\n"
"\n"
"QCheckBox::indicator:indeterminate:focus,\n"
"QCheckBox::indicator:indeterminate:hover,\n"
"QCheckBox::indicator:indeterminate:pressed {\n"
"	image: url(C:/Users/franc/AppData/Roaming/TeXstudio/rc/checkbox_indeterminate_focus.png);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked:disabled,\n"
"QGroupBox::indicator:checked:"
                        "disabled {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/checkbox_checked_disabled.png);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked:disabled,\n"
"QGroupBox::indicator:unchecked:disabled {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/checkbox_unchecked_disabled.png);\n"
"}\n"
"\n"
"/*================================================================\n"
"QMenuBar - e.g. Main toolbar (file/edit/idefix etc.)\n"
"================================================================*/\n"
"QMenuBar {\n"
"	color: #00a5a5 ;\n"
"	background-color: #00a5a5 ;\n"
"}\n"
"\n"
"QMenuBar::item {\n"
"	background: transparent;\n"
"}\n"
"\n"
"/*================================================================\n"
"QMenu\n"
"================================================================*/\n"
"QMenu {\n"
"	border: 1px solid #00a5a5 ;\n"
"	color: #eff0f1;\n"
"	margin: 2px;\n"
"}\n"
"\n"
"QMenu::separator {\n"
"	height: 2px;\n"
"	background: #00a5a5 ;\n"
"	margin-left: 5px;\n"
"	margin-right: 5px;\n"
"}\n"
"\n"
""
                        "/*================================================================\n"
"QToolbar\n"
"================================================================*/\n"
"QToolBar {\n"
"	border: 1px solid #393838;\n"
"	background: 1px solid #272a2d;\n"
"	font-weight: bold;\n"
"}\n"
"\n"
"QToolBar::handle:horizontal {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/Hmovetoolbar.png);\n"
"}\n"
"\n"
"QToolBar::handle:vertical {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/Vmovetoolbar.png);\n"
"}\n"
"\n"
"QToolBar::separator:horizontal {\n"
"	width: 2px;\n"
"	margin: 3px 10px;\n"
"	background-color: #76797C;\n"
"}\n"
"\n"
"QToolBar::separator:vertical {\n"
"	height: 2px;\n"
"	margin: 10px 3px;\n"
"	background-color: #76797C;\n"
"}\n"
"\n"
"/*================================================================\n"
"QScrollBar - e.g. Scrollbar in internal PDFviewer, editor window etc.\n"
"================================================================*/\n"
"QScrollBar:horizontal {\n"
"	height: 25px;\n"
"	margi"
                        "n: 3px 27px 3px 27px;\n"
"	border: 1px transparent #2A2929;\n"
"	border-radius: 4px;\n"
"	background-color: #000000;\n"
"}\n"
"\n"
"QScrollBar::handle:horizontal {\n"
"	background-color: #76797C;\n"
"	min-width: 15px;\n"
"	border-radius: 4px;\n"
"}\n"
"\n"
"QScrollBar::add-line:horizontal {\n"
"	margin: 0px 3px 0px 3px;\n"
"	border-image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/right_arrow_disabled.png);\n"
"	width: 20px;\n"
"	height: 20px;\n"
"	subcontrol-position: right;\n"
"	subcontrol-origin: margin;\n"
"}\n"
"\n"
"QScrollBar::sub-line:horizontal {\n"
"	margin: 0px 3px 0px 3px;\n"
"	border-image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/left_arrow_disabled.png);\n"
"	height: 20px;\n"
"	width: 20px;\n"
"	subcontrol-position: left;\n"
"	subcontrol-origin: margin;\n"
"}\n"
"\n"
"QScrollBar::add-line:horizontal:hover,\n"
"QScrollBar::add-line:horizontal:on {\n"
"	border-image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/right_arrow.png);\n"
"	height: 20px;\n"
"	width: 20px;\n"
"	subcontrol-posi"
                        "tion: right;\n"
"	subcontrol-origin: margin;\n"
"}\n"
"\n"
"QScrollBar::sub-line:horizontal:hover,\n"
"QScrollBar::sub-line:horizontal:on {\n"
"	border-image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/left_arrow.png);\n"
"	height: 20px;\n"
"	width: 20px;\n"
"	subcontrol-position: left;\n"
"	subcontrol-origin: margin;\n"
"}\n"
"\n"
"QScrollBar::up-arrow:horizontal,\n"
"QScrollBar::down-arrow:horizontal {\n"
"	background: none;\n"
"}\n"
"\n"
"QScrollBar::add-page:horizontal,\n"
"QScrollBar::sub-page:horizontal {\n"
"	background: none;\n"
"}\n"
"\n"
"QScrollBar:vertical {\n"
"	background-color: #000000;\n"
"	width: 25px;\n"
"	margin: 27px 3px 27px 3px;\n"
"	border: 1px solid #2A2929;\n"
"	border-radius: 4px;\n"
"}\n"
"\n"
"QScrollBar::handle:vertical {\n"
"	background-color: #76797C;\n"
"	min-height: 15px;\n"
"	border-radius: 4px;\n"
"}\n"
"\n"
"QScrollBar::sub-line:vertical {\n"
"	margin: 3px 0px 3px 0px;\n"
"	border-image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/up_arrow_disabled.png);\n"
"	height: "
                        "20px;\n"
"	width: 20px;\n"
"	subcontrol-position: top;\n"
"	subcontrol-origin: margin;\n"
"}\n"
"\n"
"QScrollBar::add-line:vertical {\n"
"	margin: 3px 0px 3px 0px;\n"
"	border-image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/down_arrow_disabled.png);\n"
"	height: 20px;\n"
"	width: 20px;\n"
"	subcontrol-position: bottom;\n"
"	subcontrol-origin: margin;\n"
"}\n"
"\n"
"QScrollBar::sub-line:vertical:hover,\n"
"QScrollBar::sub-line:vertical:on {\n"
"	border-image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/up_arrow.png);\n"
"	height: 20px;\n"
"	width: 20px;\n"
"	subcontrol-position: top;\n"
"	subcontrol-origin: margin;\n"
"}\n"
"\n"
"QScrollBar::add-line:vertical:hover,\n"
"QScrollBar::add-line:vertical:on {\n"
"	border-image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/down_arrow.png);\n"
"	height: 20px;\n"
"	width: 20px;\n"
"	subcontrol-position: bottom;\n"
"	subcontrol-origin: margin;\n"
"}\n"
"\n"
"QScrollBar::up-arrow:vertical,\n"
"QScrollBar::down-arrow:vertical {\n"
"	background: none;\n"
"}\n"
""
                        "\n"
"QScrollBar::add-page:vertical,\n"
"QScrollBar::sub-page:vertical {\n"
"	background: none;\n"
"}\n"
"\n"
"/*================================================================\n"
"QTabBar - e.g. File tabs (top), Bottom panel tabs (top), Autocompleter window tabs (bottom)\n"
"================================================================*/\n"
"QTabBar {\n"
"	qproperty-drawBase: 0; /* important */\n"
"	background-color: transparent;\n"
"}\n"
"\n"
"/* <FIX> Workaround for QTabBars created from docked QDockWidgets which don't draw the border if not set and reseted as follows: */\n"
"QTabBar {\n"
"	border-top: 1px transparent #76797C;  /* set color for all QTabBars */\n"
"}\n"
"QDialog QTabBar {\n"
"	border-color: transparent; /* set color for QTabBars inside Preferences dialog */\n"
"}\n"
"/* </FIX> */\n"
"\n"
"QTabBar::close-button {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/close.png);\n"
"	background: transparent;\n"
"	margin-top: 6px;\n"
"	margin-bottom: 6px;\n"
"}\n"
"\n"
"QTabBar::close-b"
                        "utton:hover {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/close-hover.png);\n"
"	background: transparent;\n"
"	margin-top: 6px;\n"
"	margin-bottom: 6px;\n"
"}\n"
"\n"
"QTabBar::close-button:pressed {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/close-pressed.png);\n"
"	background: transparent;\n"
"	margin-top: 6px;\n"
"	margin-bottom: 6px;\n"
"}\n"
"\n"
"/* TOP TABS */\n"
"\n"
"QTabBar::tab:top {\n"
"	color: #eff0f1;\n"
"	border: 1px solid #76797C;\n"
"	border-bottom: 1px transparent black;\n"
"	background-color: #31363b;\n"
"	padding: 5px;\n"
"	min-width: 50px;\n"
"	border-top-left-radius: 6px;\n"
"	border-top-right-radius: 6px;\n"
"}\n"
"\n"
"QTabBar::tab:top:selected {\n"
"	color: #eff0f1;\n"
"	background-color: #54575B;\n"
"	border: 2px solid #76797C;\n"
"	border-bottom: 3px solid #00a5a5 ;\n"
"	border-top-left-radius: 6px;\n"
"	border-top-right-radius: 6px;\n"
"}\n"
"\n"
"QTabBar::tab:top:!selected:hover {\n"
"	background-color: #18465d;\n"
"}\n"
"\n"
"/* BOTTOM TABS */\n"
"\n"
""
                        "QTabBar::tab:bottom {\n"
"	color: #eff0f1;\n"
"	border: 1px solid #76797C;\n"
"	border-top: 1px transparent black;\n"
"	background-color: #31363b;\n"
"	padding: 5px;\n"
"	border-bottom-left-radius: 6px;\n"
"	border-bottom-right-radius: 6px;\n"
"	min-width: 50px;\n"
"}\n"
"\n"
"QTabBar::tab:bottom:selected {\n"
"	color: #eff0f1;\n"
"	background-color: #54575B;\n"
"	border: 2px solid #76797C;\n"
"	border-top: 3px solid #3daee9;\n"
"	border-bottom-left-radius: 6px;\n"
"	border-bottom-right-radius: 6px;\n"
"}\n"
"\n"
"QTabBar::tab:bottom:!selected:hover {\n"
"	background-color: #18465d;\n"
"}\n"
"\n"
"/*================================================================\n"
"QDockWidget - e.g. \"Search\" header in internal PDF viewer \n"
"================================================================*/\n"
"QDockWidget {\n"
"	titlebar-close-icon: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/transparent.png);\n"
"	titlebar-normal-icon: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/transparent.png);\n"
"}\n"
"\n"
"Q"
                        "DockWidget::title {\n"
"	background: #373b3f; \n"
"	color: transparent;\n"
"	border: 1px transparent;\n"
"	text-align: left;\n"
"}\n"
"\n"
"QDockWidget::close-button,\n"
"QDockWidget::float-button {\n"
"	border: transparent;\n"
"	padding: 0px;\n"
"	icon-size: 25px;\n"
"	background: transparent;\n"
"}\n"
"\n"
"QDockWidget::float-button {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/undock.png);\n"
"	subcontrol-position: right center;\n"
"	left: -50px;\n"
"}\n"
"\n"
"QDockWidget::close-button {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/close.png);\n"
"	subcontrol-position: right center;\n"
"	left: -10px;\n"
"}\n"
"\n"
"QDockWidget::float-button:hover {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/undock-pressed.png);\n"
"	subcontrol-position: right center;\n"
"	left: -50px;\n"
"}\n"
"\n"
"QDockWidget::close-button:hover {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/close-pressed.png);\n"
"	subcontrol-position: right center;\n"
"	left: -10px;\n"
"}\n"
"\n"
""
                        "QDockWidget::close-button:pressed {\n"
"	padding: 2px -2px -2px 2px;\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/close-pressed.png);\n"
"}\n"
"\n"
"QDockWidget::float-button:pressed {\n"
"	padding: 2px -2px -2px 2px;\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/undock-pressed.png);\n"
"}\n"
"\n"
"QDockWidget QListView {\n"
"	outline: 0;\n"
"	background: #272a2d;\n"
"	alternate-background-color: #373b3f;\n"
"	color: #eff0f1;\n"
"}\n"
"\n"
"/*================================================================\n"
"QTreeView, QListView\n"
"================================================================*/\n"
"QTreeView,\n"
"QListView {\n"
"	border: 1px solid #76797C;\n"
"	background-color: #232629;\n"
"}\n"
"\n"
"QTreeView:branch:selected,\n"
"QTreeView:branch:hover {\n"
"	background: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/transparent.png);\n"
"}\n"
"\n"
"QTreeView::branch:has-siblings:!adjoins-item {\n"
"	border-image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/transparent.pn"
                        "g);\n"
"}\n"
"\n"
"QTreeView::branch:has-siblings:adjoins-item {\n"
"	border-image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/transparent.png);\n"
"}\n"
"\n"
"QTreeView::branch:!has-children:!has-siblings:adjoins-item {\n"
"	border-image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/transparent.png);\n"
"}\n"
"\n"
"QTreeView::branch:has-children:!has-siblings:closed,\n"
"QTreeView::branch:closed:has-children:has-siblings {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/branch_closed.png);\n"
"}\n"
"\n"
"QTreeView::branch:open:has-children:!has-siblings,\n"
"QTreeView::branch:open:has-children:has-siblings {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/branch_open.png);\n"
"}\n"
"\n"
"QTreeView::branch:has-children:!has-siblings:closed:hover,\n"
"QTreeView::branch:closed:has-children:has-siblings:hover {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/branch_closed-on.png);\n"
"}\n"
"\n"
"QTreeView::branch:open:has-children:!has-siblings:hover,\n"
"QTreeView::branch:o"
                        "pen:has-children:has-siblings:hover {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/branch_open-on.png);\n"
"}\n"
"\n"
"QListView::item:!selected:hover,\n"
"QTreeView::item:!selected:hover {\n"
"	background: #18465d;\n"
"	outline: 0;\n"
"	color: #eff0f1;\n"
"}\n"
"\n"
"QListView::item:selected:hover,\n"
"QTreeView::item:selected:hover {\n"
"	background: #287399;\n"
"	color: #eff0f1;\n"
"}\n"
"\n"
"QTreeView::indicator:checked,\n"
"QListView::indicator:checked {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/checkbox_checked.png);\n"
"}\n"
"\n"
"QTreeView::indicator:unchecked,\n"
"QListView::indicator:unchecked {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/checkbox_unchecked.png);\n"
"}\n"
"\n"
"QTreeView::indicator:checked:hover,\n"
"QTreeView::indicator:checked:focus,\n"
"QTreeView::indicator:checked:pressed,\n"
"QListView::indicator:checked:hover,\n"
"QListView::indicator:checked:focus,\n"
"QListView::indicator:checked:pressed {\n"
"	image: url(C:/Users/user/AppData/Ro"
                        "aming/TeXstudio/rc/checkbox_checked_focus.png);\n"
"}\n"
"\n"
"QTreeView::indicator:unchecked:hover,\n"
"QTreeView::indicator:unchecked:focus,\n"
"QTreeView::indicator:unchecked:pressed,\n"
"QListView::indicator:unchecked:hover,\n"
"QListView::indicator:unchecked:focus,\n"
"QListView::indicator:unchecked:pressed {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/checkbox_unchecked_focus.png);\n"
"}\n"
"\n"
"/*================================================================\n"
"QPushButton\n"
"================================================================*/\n"
"QPushButton {\n"
"	color: #eff0f1;\n"
"	background-color: #31363b;\n"
"	border-width: 1px;\n"
"	border-color: #76797C;\n"
"	border-style: solid;\n"
"	padding: 5px;\n"
"	border-radius: 2px;\n"
"	outline: none;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"	background-color: #00a5a5;\n"
"	border-width: 1px;\n"
"	border-color: #454545;\n"
"	border-style: solid;\n"
"	padding-top: 5px;\n"
"	padding-bottom: 5px;\n"
"	padding-left: 10px;\n"
"	padding-ri"
                        "ght: 10px;\n"
"	border-radius: 2px;\n"
"	color: #454545;\n"
"}\n"
"\n"
"QPushButton:hover,\n"
"QPushButton:focus {\n"
"	background-color: #00a5a5;\n"
"	color: #ffffff;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: #00a5a5;\n"
"	padding-top: -15px;\n"
"	padding-bottom: -17px;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"	background-color: #00a5a5;\n"
"	border-color: #6A6969;\n"
"}\n"
"\n"
"/*================================================================\n"
"QToolButton - e.g. Reset pushbutton in GUI scaling, toolbar buttons\n"
"================================================================*/\n"
"QToolButton {\n"
"	text-align: center;\n"
"}\n"
"\n"
"/*================================================================\n"
"QComboBox\n"
"================================================================*/\n"
"QComboBox {\n"
"	selection-background-color: #db1c49;\n"
"	border: 1px solid #76797C;\n"
"	border-radius: 2px;\n"
"	padding: 5px;\n"
"	min-width: 75px;\n"
"}\n"
"\n"
"QComboBox:hover,\n"
"QPushButton"
                        ":hover,\n"
"QAbstractSpinBox:hover,\n"
"QLineEdit:hover,\n"
"QTextEdit:hover,\n"
"QPlainTextEdit:hover,\n"
"QAbstractView:hover,\n"
"QTreeView:hover {\n"
"	border: 1px solid #009494 ;\n"
"	color: #eff0f1;\n"
"}\n"
"\n"
"QComboBox:on {\n"
"	padding-top: 3px;\n"
"	padding-left: 4px;\n"
"	selection-background-color: #4a4a4a;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"	background-color: #232629;\n"
"	border-radius: 2px;\n"
"	border: 1px solid #76797C;\n"
"	selection-background-color: #18465d;\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"	subcontrol-origin: padding;\n"
"	subcontrol-position: top right;\n"
"	width: 35px;\n"
"	border-left-width: 0px;\n"
"	border-left-color: darkgray;\n"
"	border-left-style: solid;\n"
"	border-top-right-radius: 3px;\n"
"	border-bottom-right-radius: 3px;\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/down_arrow_disabled.png);\n"
"}\n"
"\n"
"QComboBox::down-arrow:on,\n"
"QComboBox::down-arrow:hover,\n"
"QComboBox::down-arrow:focus {\n"
""
                        "	image: url(C:/Users/user/AppData/Roaming/TeXstudio/rc/down_arrow.png);\n"
"}\n"
"\n"
"/*================================================================\n"
"QLineEdit - e.g. Search textbox in internal pdf viewer\n"
"================================================================*/\n"
"QLineEdit {\n"
"	selection-background-color: #db1c49;\n"
"	border: 1px solid #76797C;\n"
"}\n"
"\n"
"/*================================================================\n"
"QHeaderView\n"
"================================================================*/\n"
"QHeaderView {\n"
"	background-color: #31363b;\n"
"	border: 1px transparent;\n"
"	border-radius: 0px;\n"
"	margin: 0px;\n"
"	padding: 0px;\n"
"}\n"
"\n"
"QHeaderView::section {\n"
"	background-color: #31363b;\n"
"	color: #eff0f1;\n"
"	padding: 5px;\n"
"	border: 1px solid #76797C;\n"
"	border-radius: 0px;\n"
"	text-align: center;\n"
"}\n"
"\n"
"QHeaderView::section::vertical::first,\n"
"QHeaderView::section::vertical::only-one {\n"
"	border-top: 1px solid #76797C;\n"
"}\n"
"\n"
""
                        "QHeaderView::section::vertical {\n"
"	border-top: transparent;\n"
"}\n"
"\n"
"QHeaderView::section::horizontal::first,\n"
"QHeaderView::section::horizontal::only-one {\n"
"	border-left: 1px solid #76797C;\n"
"}\n"
"\n"
"QHeaderView::section::horizontal {\n"
"	border-left: transparent;\n"
"}\n"
"\n"
"QHeaderView::section:checked {\n"
"	color: #ffffff;\n"
"	background-color: #31363B;\n"
"}\n"
"\n"
"/*================================================================\n"
"QTableWidget\n"
"================================================================*/\n"
"QTableWidget {\n"
"	background-color: #373b3f; /*#232629;*/\n"
"	gridline-color: yellow; /*#31363b;*/\n"
"}\n"
"\n"
"QTableWidget::item {\n"
"	outline-style: none;\n"
"	color: #eff0f1;\n"
"	background: #31363b;\n"
"	border: none;\n"
"	border-bottom: 1px solid #31363b;\n"
"}\n"
"\n"
"/*================================================================\n"
"QTableView - e.g. configMenu()->Syntax highlighting table\n"
"================================================="
                        "===============*/\n"
"QTableView {\n"
"	border: 1px solid #76797C;\n"
"	gridline-color: #31363b;\n"
"	background-color: #232629;\n"
"}\n"
"\n"
"QTableView,\n"
"QHeaderView {\n"
"	border-radius: 0px;\n"
"}\n"
"\n"
"QTableView::item:hover {\n"
"	background: #18465d;\n"
"}\n"
"\n"
"QTableView::item:pressed,\n"
"QListView::item:pressed,\n"
"QTreeView::item:pressed {\n"
"	background: #18465d;\n"
"	color: #eff0f1;\n"
"}\n"
"\n"
"QTableView::item:selected:active,\n"
"QTreeView::item:selected:active,\n"
"QListView::item:selected:active {\n"
"	background: #287399;\n"
"	color: #eff0f1;\n"
"}\n"
"\n"
"QTableCornerButton::section {\n"
"	background-color: #31363b;\n"
"	border: 1px transparent #76797C;\n"
"	border-radius: 0px;\n"
"}\n"
"\n"
"/*================================================================\n"
"QDialog - e.g. config menu, About TXS window, Wizards\n"
"================================================================*/\n"
"QDialog {\n"
"	background-color: #373b3f;\n"
"}\n"
"\n"
"QDialog QCheckBox,\n"
"QDialog"
                        " QLabel {\n"
"	background-color: transparent;\n"
"}\n"
"\n"
"QDialog QToolButton { /*Same as QPushButton*/\n"
"	color: #eff0f1;\n"
"	background-color: #31363b;\n"
"	border-width: 1px;\n"
"	border-color: #76797C;\n"
"	border-style: solid;\n"
"	padding: 5px;\n"
"	border-radius: 2px;\n"
"	outline: none;\n"
"}\n"
"\n"
"QDialog QToolButton:hover,\n"
"QDialog QToolButton:focus { /*Same as QPushButton*/\n"
"	background-color: #18465d;\n"
"	color: #ffffff;\n"
"}\n"
"\n"
"QDialog QToolButton:pressed { /*Same as QPushButton*/\n"
"	background-color: #18465d;\n"
"	padding-top: -15px;\n"
"	padding-bottom: -17px;\n"
"}\n"
"\n"
"/* <FIX> Specific to table in \"configMenu->Syntax highlighting\" (hopefully) */\n"
"\n"
"QDialog QTableWidget::item,\n"
"QDialog QTableView::item:hover { /* Turn off hover colour for cells -- it's distracting */\n"
"	background-color: #31363b;\n"
"}\n"
"\n"
"/* </FIX> */\n"
"\n"
"/*================================================================\n"
"QSlider - e.g. GUI scaling settings\n"
"=========="
                        "======================================================*/\n"
"QSlider,\n"
"QSlider:active,\n"
"QSlider:!active {\n"
"	border: none;\n"
"	background-color: transparent;\n"
"}\n"
"\n"
"QSlider::groove:horizontal {\n"
"	height: 12px;\n"
"}\n"
"\n"
"QSlider::groove:vertical {\n"
"	width: 12px;\n"
"}\n"
"\n"
"QSlider::handle:horizontal,\n"
"QSlider::handle:vertical {\n"
"	background-color: #db1c49;\n"
"	border: 1px solid #db1c49;\n"
"	width: 10px;\n"
"	height: 15px;\n"
"	border-radius: 8px;\n"
"}\n"
"\n"
"QSlider::handle:horizontal:hover,\n"
"QSlider::handle:vertical:hover,\n"
"QSlider::handle:horizontal:pressed,\n"
"QSlider::handle:vertical:pressed {\n"
"	border: 1px solid #A21538;\n"
"	background-color: #A21538;\n"
"}\n"
"\n"
"/*================================================================\n"
"QToolTip - e.g. popup upon hovering on filename tabs\n"
"================================================================*/\n"
"QToolTip {\n"
"    border: 1px solid #272a2d;\n"
"    background-color: #373b3f;\n"
"    colo"
                        "r: white;\n"
"    padding: 0px;                /*remove padding, for fix combobox tooltip.*/\n"
"}\n"
"\n"
"/*================================================================\n"
"END\n"
"================================================================*/"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setObjectName("horizontalLayout");
        frame_2 = new QFrame(centralwidget);
        frame_2->setObjectName("frame_2");
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        verticalLayout = new QVBoxLayout(frame_2);
        verticalLayout->setObjectName("verticalLayout");
        pushButton = new QPushButton(frame_2);
        pushButton->setObjectName("pushButton");
        QFont font;
        font.setPointSize(11);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QString::fromUtf8("border-radius:5px;"));

        verticalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(frame_2);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setFont(font);
        pushButton_2->setStyleSheet(QString::fromUtf8("backgroung-color:#00a5a5;"));

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(frame_2);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setFont(font);
        pushButton_3->setStyleSheet(QString::fromUtf8("border-radius:5px;"));

        verticalLayout->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(frame_2);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setFont(font);
        pushButton_4->setStyleSheet(QString::fromUtf8("border-radius:5px;"));

        verticalLayout->addWidget(pushButton_4);

        pushButton_7 = new QPushButton(frame_2);
        pushButton_7->setObjectName("pushButton_7");
        pushButton_7->setFont(font);
        pushButton_7->setStyleSheet(QString::fromUtf8("border-radius:5px;"));

        verticalLayout->addWidget(pushButton_7);

        pushButton_6 = new QPushButton(frame_2);
        pushButton_6->setObjectName("pushButton_6");
        pushButton_6->setFont(font);
        pushButton_6->setStyleSheet(QString::fromUtf8("border-radius:5px;"));

        verticalLayout->addWidget(pushButton_6);

        pushButton_5 = new QPushButton(frame_2);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setFont(font);
        pushButton_5->setStyleSheet(QString::fromUtf8("border-radius:5px;"));

        verticalLayout->addWidget(pushButton_5);


        horizontalLayout->addWidget(frame_2);

        frame = new QFrame(centralwidget);
        frame->setObjectName("frame");
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        verticalLayout_13 = new QVBoxLayout(frame);
        verticalLayout_13->setObjectName("verticalLayout_13");
        stackedWidget = new QStackedWidget(frame);
        stackedWidget->setObjectName("stackedWidget");
        page = new QWidget();
        page->setObjectName("page");
        verticalLayout_2 = new QVBoxLayout(page);
        verticalLayout_2->setObjectName("verticalLayout_2");
        frame_3 = new QFrame(page);
        frame_3->setObjectName("frame_3");
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        verticalLayout_3 = new QVBoxLayout(frame_3);
        verticalLayout_3->setObjectName("verticalLayout_3");
        label = new QLabel(frame_3);
        label->setObjectName("label");
        QFont font1;
        font1.setPointSize(15);
        label->setFont(font1);
        label->setStyleSheet(QString::fromUtf8("padding:4px;\n"
""));
        label->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label, 0, Qt::AlignTop);


        verticalLayout_2->addWidget(frame_3, 0, Qt::AlignTop);

        frame_4 = new QFrame(page);
        frame_4->setObjectName("frame_4");
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(frame_4->sizePolicy().hasHeightForWidth());
        frame_4->setSizePolicy(sizePolicy);
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        label_21 = new QLabel(frame_4);
        label_21->setObjectName("label_21");
        label_21->setGeometry(QRect(440, 10, 201, 41));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Segoe UI")});
        font2.setPointSize(14);
        font2.setBold(false);
        font2.setItalic(false);
        label_21->setFont(font2);
        label_21->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";\n"
"padding: 2pt;\n"
"background-color:#007373 ;"));
        label_21->setAlignment(Qt::AlignCenter);
        label_22 = new QLabel(frame_4);
        label_22->setObjectName("label_22");
        label_22->setGeometry(QRect(80, 70, 931, 401));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_22->sizePolicy().hasHeightForWidth());
        label_22->setSizePolicy(sizePolicy1);
        QFont font3;
        font3.setPointSize(12);
        label_22->setFont(font3);
        label_22->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);

        verticalLayout_2->addWidget(frame_4);

        stackedWidget->addWidget(page);
        page_3 = new QWidget();
        page_3->setObjectName("page_3");
        verticalLayout_10 = new QVBoxLayout(page_3);
        verticalLayout_10->setObjectName("verticalLayout_10");
        frame_7 = new QFrame(page_3);
        frame_7->setObjectName("frame_7");
        frame_7->setFrameShape(QFrame::StyledPanel);
        frame_7->setFrameShadow(QFrame::Raised);
        verticalLayout_8 = new QVBoxLayout(frame_7);
        verticalLayout_8->setObjectName("verticalLayout_8");
        label_3 = new QLabel(frame_7);
        label_3->setObjectName("label_3");
        label_3->setFont(font1);
        label_3->setStyleSheet(QString::fromUtf8("padding: 2px"));
        label_3->setAlignment(Qt::AlignCenter);

        verticalLayout_8->addWidget(label_3, 0, Qt::AlignTop);


        verticalLayout_10->addWidget(frame_7);

        frame_8 = new QFrame(page_3);
        frame_8->setObjectName("frame_8");
        sizePolicy.setHeightForWidth(frame_8->sizePolicy().hasHeightForWidth());
        frame_8->setSizePolicy(sizePolicy);
        frame_8->setFrameShape(QFrame::StyledPanel);
        frame_8->setFrameShadow(QFrame::Raised);
        lineEdit_6 = new QLineEdit(frame_8);
        lineEdit_6->setObjectName("lineEdit_6");
        lineEdit_6->setGeometry(QRect(310, 190, 471, 51));
        lineEdit_6->setFont(font3);
        lineEdit_6->setAlignment(Qt::AlignCenter);
        pushButton_14 = new QPushButton(frame_8);
        pushButton_14->setObjectName("pushButton_14");
        pushButton_14->setGeometry(QRect(510, 290, 101, 41));
        QFont font4;
        font4.setPointSize(10);
        pushButton_14->setFont(font4);

        verticalLayout_10->addWidget(frame_8);

        stackedWidget->addWidget(page_3);
        page_5 = new QWidget();
        page_5->setObjectName("page_5");
        verticalLayout_16 = new QVBoxLayout(page_5);
        verticalLayout_16->setObjectName("verticalLayout_16");
        frame_11 = new QFrame(page_5);
        frame_11->setObjectName("frame_11");
        frame_11->setFrameShape(QFrame::StyledPanel);
        frame_11->setFrameShadow(QFrame::Raised);
        verticalLayout_14 = new QVBoxLayout(frame_11);
        verticalLayout_14->setObjectName("verticalLayout_14");
        label_5 = new QLabel(frame_11);
        label_5->setObjectName("label_5");
        label_5->setFont(font1);
        label_5->setStyleSheet(QString::fromUtf8("padding:2px"));
        label_5->setAlignment(Qt::AlignCenter);

        verticalLayout_14->addWidget(label_5, 0, Qt::AlignTop);

        frame_12 = new QFrame(frame_11);
        frame_12->setObjectName("frame_12");
        sizePolicy.setHeightForWidth(frame_12->sizePolicy().hasHeightForWidth());
        frame_12->setSizePolicy(sizePolicy);
        frame_12->setFrameShape(QFrame::StyledPanel);
        frame_12->setFrameShadow(QFrame::Raised);
        lineEdit_7 = new QLineEdit(frame_12);
        lineEdit_7->setObjectName("lineEdit_7");
        lineEdit_7->setGeometry(QRect(170, 190, 721, 61));
        lineEdit_7->setFont(font3);
        lineEdit_7->setAlignment(Qt::AlignCenter);
        pushButton_15 = new QPushButton(frame_12);
        pushButton_15->setObjectName("pushButton_15");
        pushButton_15->setGeometry(QRect(470, 320, 121, 51));
        pushButton_15->setFont(font4);
        pushButton_15->setCursor(QCursor(Qt::BlankCursor));

        verticalLayout_14->addWidget(frame_12);


        verticalLayout_16->addWidget(frame_11);

        stackedWidget->addWidget(page_5);
        page_4 = new QWidget();
        page_4->setObjectName("page_4");
        verticalLayout_17 = new QVBoxLayout(page_4);
        verticalLayout_17->setObjectName("verticalLayout_17");
        frame_9 = new QFrame(page_4);
        frame_9->setObjectName("frame_9");
        frame_9->setFrameShape(QFrame::StyledPanel);
        frame_9->setFrameShadow(QFrame::Raised);
        verticalLayout_11 = new QVBoxLayout(frame_9);
        verticalLayout_11->setObjectName("verticalLayout_11");
        label_4 = new QLabel(frame_9);
        label_4->setObjectName("label_4");
        QFont font5;
        font5.setPointSize(14);
        label_4->setFont(font5);
        label_4->setStyleSheet(QString::fromUtf8("padding:4px;"));
        label_4->setAlignment(Qt::AlignCenter);

        verticalLayout_11->addWidget(label_4);


        verticalLayout_17->addWidget(frame_9);

        frame_10 = new QFrame(page_4);
        frame_10->setObjectName("frame_10");
        sizePolicy.setHeightForWidth(frame_10->sizePolicy().hasHeightForWidth());
        frame_10->setSizePolicy(sizePolicy);
        frame_10->setFrameShape(QFrame::StyledPanel);
        frame_10->setFrameShadow(QFrame::Raised);
        verticalLayout_12 = new QVBoxLayout(frame_10);
        verticalLayout_12->setSpacing(0);
        verticalLayout_12->setObjectName("verticalLayout_12");
        verticalLayout_12->setContentsMargins(0, 0, 0, 0);
        tabWidget_4 = new QTabWidget(frame_10);
        tabWidget_4->setObjectName("tabWidget_4");
        tabWidget_4->setFont(font4);
        tab_7 = new QWidget();
        tab_7->setObjectName("tab_7");
        lineEdit = new QLineEdit(tab_7);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setGeometry(QRect(320, 170, 481, 61));
        lineEdit->setFont(font3);
        lineEdit->setAlignment(Qt::AlignCenter);
        pushButton_8 = new QPushButton(tab_7);
        pushButton_8->setObjectName("pushButton_8");
        pushButton_8->setGeometry(QRect(500, 270, 131, 41));
        pushButton_8->setFont(font4);
        tabWidget_4->addTab(tab_7, QString());
        tab_8 = new QWidget();
        tab_8->setObjectName("tab_8");
        label_6 = new QLabel(tab_8);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(290, 150, 491, 51));
        label_6->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";\n"
"background-color:#007373 ;"));
        label_6->setAlignment(Qt::AlignCenter);
        pushButton_9 = new QPushButton(tab_8);
        pushButton_9->setObjectName("pushButton_9");
        pushButton_9->setGeometry(QRect(500, 250, 83, 29));
        pushButton_9->setFont(font4);
        tabWidget_4->addTab(tab_8, QString());
        tab_11 = new QWidget();
        tab_11->setObjectName("tab_11");
        label_8 = new QLabel(tab_11);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(430, 30, 231, 41));
        label_8->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";\n"
"background-color:#007373 ;"));
        label_8->setAlignment(Qt::AlignCenter);
        label_9 = new QLabel(tab_11);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(80, 100, 931, 351));
        sizePolicy1.setHeightForWidth(label_9->sizePolicy().hasHeightForWidth());
        label_9->setSizePolicy(sizePolicy1);
        label_9->setFont(font3);
        label_9->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        tabWidget_4->addTab(tab_11, QString());

        verticalLayout_12->addWidget(tabWidget_4);


        verticalLayout_17->addWidget(frame_10);

        stackedWidget->addWidget(page_4);
        page_7 = new QWidget();
        page_7->setObjectName("page_7");
        verticalLayout_22 = new QVBoxLayout(page_7);
        verticalLayout_22->setObjectName("verticalLayout_22");
        frame_15 = new QFrame(page_7);
        frame_15->setObjectName("frame_15");
        frame_15->setFrameShape(QFrame::StyledPanel);
        frame_15->setFrameShadow(QFrame::Raised);
        verticalLayout_20 = new QVBoxLayout(frame_15);
        verticalLayout_20->setObjectName("verticalLayout_20");
        label_7 = new QLabel(frame_15);
        label_7->setObjectName("label_7");
        label_7->setFont(font5);
        label_7->setStyleSheet(QString::fromUtf8("padding:4px;"));
        label_7->setAlignment(Qt::AlignCenter);

        verticalLayout_20->addWidget(label_7, 0, Qt::AlignTop);


        verticalLayout_22->addWidget(frame_15);

        frame_16 = new QFrame(page_7);
        frame_16->setObjectName("frame_16");
        sizePolicy.setHeightForWidth(frame_16->sizePolicy().hasHeightForWidth());
        frame_16->setSizePolicy(sizePolicy);
        frame_16->setFrameShape(QFrame::StyledPanel);
        frame_16->setFrameShadow(QFrame::Raised);
        verticalLayout_21 = new QVBoxLayout(frame_16);
        verticalLayout_21->setSpacing(0);
        verticalLayout_21->setObjectName("verticalLayout_21");
        verticalLayout_21->setContentsMargins(0, 0, 0, 0);
        tabWidget_7 = new QTabWidget(frame_16);
        tabWidget_7->setObjectName("tabWidget_7");
        tabWidget_7->setFont(font4);
        tab_13 = new QWidget();
        tab_13->setObjectName("tab_13");
        label_10 = new QLabel(tab_13);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(430, 30, 231, 41));
        label_10->setFont(font2);
        label_10->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";\n"
"background-color:#007373 ;"));
        label_10->setAlignment(Qt::AlignCenter);
        label_11 = new QLabel(tab_13);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(80, 110, 901, 321));
        sizePolicy1.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy1);
        label_11->setFont(font3);
        label_11->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        tabWidget_7->addTab(tab_13, QString());
        tab_14 = new QWidget();
        tab_14->setObjectName("tab_14");
        lineEdit_2 = new QLineEdit(tab_14);
        lineEdit_2->setObjectName("lineEdit_2");
        lineEdit_2->setGeometry(QRect(320, 20, 481, 41));
        lineEdit_2->setFont(font3);
        lineEdit_2->setAlignment(Qt::AlignCenter);
        stackedWidget_2 = new QStackedWidget(tab_14);
        stackedWidget_2->setObjectName("stackedWidget_2");
        stackedWidget_2->setGeometry(QRect(100, 240, 921, 231));
        page_6 = new QWidget();
        page_6->setObjectName("page_6");
        stackedWidget_2->addWidget(page_6);
        page_8 = new QWidget();
        page_8->setObjectName("page_8");
        lineEdit_3 = new QLineEdit(page_8);
        lineEdit_3->setObjectName("lineEdit_3");
        lineEdit_3->setGeometry(QRect(10, 10, 361, 41));
        lineEdit_3->setFont(font4);
        lineEdit_3->setAlignment(Qt::AlignCenter);
        lineEdit_8 = new QLineEdit(page_8);
        lineEdit_8->setObjectName("lineEdit_8");
        lineEdit_8->setGeometry(QRect(410, 10, 481, 41));
        lineEdit_8->setFont(font3);
        lineEdit_8->setAlignment(Qt::AlignCenter);
        pushButton_16 = new QPushButton(page_8);
        pushButton_16->setObjectName("pushButton_16");
        pushButton_16->setGeometry(QRect(340, 110, 83, 29));
        pushButton_16->setFont(font4);
        stackedWidget_2->addWidget(page_8);
        label_23 = new QLabel(tab_14);
        label_23->setObjectName("label_23");
        label_23->setGeometry(QRect(100, 80, 901, 141));
        sizePolicy1.setHeightForWidth(label_23->sizePolicy().hasHeightForWidth());
        label_23->setSizePolicy(sizePolicy1);
        label_23->setFont(font3);
        label_23->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        pushButton_10 = new QPushButton(tab_14);
        pushButton_10->setObjectName("pushButton_10");
        pushButton_10->setGeometry(QRect(860, 30, 83, 29));
        pushButton_10->setFont(font4);
        tabWidget_7->addTab(tab_14, QString());
        tab_12 = new QWidget();
        tab_12->setObjectName("tab_12");
        label_12 = new QLabel(tab_12);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(420, 30, 231, 41));
        label_12->setFont(font2);
        label_12->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";\n"
"background-color:#007373 ;"));
        label_12->setAlignment(Qt::AlignCenter);
        label_13 = new QLabel(tab_12);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(60, 110, 941, 321));
        sizePolicy1.setHeightForWidth(label_13->sizePolicy().hasHeightForWidth());
        label_13->setSizePolicy(sizePolicy1);
        label_13->setFont(font3);
        label_13->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        tabWidget_7->addTab(tab_12, QString());
        tab_15 = new QWidget();
        tab_15->setObjectName("tab_15");
        lineEdit_4 = new QLineEdit(tab_15);
        lineEdit_4->setObjectName("lineEdit_4");
        lineEdit_4->setGeometry(QRect(320, 190, 441, 51));
        lineEdit_4->setFont(font3);
        lineEdit_4->setAlignment(Qt::AlignCenter);
        pushButton_11 = new QPushButton(tab_15);
        pushButton_11->setObjectName("pushButton_11");
        pushButton_11->setGeometry(QRect(500, 300, 83, 41));
        pushButton_11->setFont(font4);
        label_14 = new QLabel(tab_15);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(310, 100, 461, 41));
        label_14->setFont(font2);
        label_14->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";\n"
"background-color:#007373 ;"));
        label_14->setAlignment(Qt::AlignCenter);
        tabWidget_7->addTab(tab_15, QString());

        verticalLayout_21->addWidget(tabWidget_7);


        verticalLayout_22->addWidget(frame_16);

        stackedWidget->addWidget(page_7);
        page_2 = new QWidget();
        page_2->setObjectName("page_2");
        verticalLayout_7 = new QVBoxLayout(page_2);
        verticalLayout_7->setObjectName("verticalLayout_7");
        frame_5 = new QFrame(page_2);
        frame_5->setObjectName("frame_5");
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Raised);
        verticalLayout_5 = new QVBoxLayout(frame_5);
        verticalLayout_5->setObjectName("verticalLayout_5");
        label_2 = new QLabel(frame_5);
        label_2->setObjectName("label_2");
        label_2->setFont(font1);
        label_2->setStyleSheet(QString::fromUtf8("padding: 4px;"));
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout_5->addWidget(label_2, 0, Qt::AlignTop);


        verticalLayout_7->addWidget(frame_5);

        frame_6 = new QFrame(page_2);
        frame_6->setObjectName("frame_6");
        sizePolicy.setHeightForWidth(frame_6->sizePolicy().hasHeightForWidth());
        frame_6->setSizePolicy(sizePolicy);
        frame_6->setFrameShape(QFrame::StyledPanel);
        frame_6->setFrameShadow(QFrame::Raised);
        verticalLayout_6 = new QVBoxLayout(frame_6);
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setObjectName("verticalLayout_6");
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        tabWidget_2 = new QTabWidget(frame_6);
        tabWidget_2->setObjectName("tabWidget_2");
        tabWidget_2->setFont(font4);
        tabWidget_2->setStyleSheet(QString::fromUtf8(""));
        tab_3 = new QWidget();
        tab_3->setObjectName("tab_3");
        label_15 = new QLabel(tab_3);
        label_15->setObjectName("label_15");
        label_15->setGeometry(QRect(70, 190, 951, 251));
        sizePolicy1.setHeightForWidth(label_15->sizePolicy().hasHeightForWidth());
        label_15->setSizePolicy(sizePolicy1);
        label_15->setFont(font3);
        label_15->setStyleSheet(QString::fromUtf8(""));
        label_15->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        lineEdit_9 = new QLineEdit(tab_3);
        lineEdit_9->setObjectName("lineEdit_9");
        lineEdit_9->setGeometry(QRect(330, 40, 441, 51));
        lineEdit_9->setFont(font3);
        lineEdit_9->setAlignment(Qt::AlignCenter);
        pushButton_18 = new QPushButton(tab_3);
        pushButton_18->setObjectName("pushButton_18");
        pushButton_18->setGeometry(QRect(510, 120, 83, 41));
        pushButton_18->setFont(font4);
        tabWidget_2->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName("tab_4");
        label_16 = new QLabel(tab_4);
        label_16->setObjectName("label_16");
        label_16->setGeometry(QRect(70, 70, 951, 241));
        sizePolicy1.setHeightForWidth(label_16->sizePolicy().hasHeightForWidth());
        label_16->setSizePolicy(sizePolicy1);
        label_16->setFont(font3);
        label_16->setStyleSheet(QString::fromUtf8(""));
        label_16->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        lineEdit_5 = new QLineEdit(tab_4);
        lineEdit_5->setObjectName("lineEdit_5");
        lineEdit_5->setGeometry(QRect(320, 340, 471, 51));
        lineEdit_5->setFont(font3);
        lineEdit_5->setAlignment(Qt::AlignCenter);
        pushButton_12 = new QPushButton(tab_4);
        pushButton_12->setObjectName("pushButton_12");
        pushButton_12->setGeometry(QRect(500, 420, 111, 31));
        pushButton_12->setFont(font4);
        label_20 = new QLabel(tab_4);
        label_20->setObjectName("label_20");
        label_20->setGeometry(QRect(460, 20, 171, 31));
        label_20->setFont(font5);
        label_20->setStyleSheet(QString::fromUtf8("background-color:#007373 ;"));
        label_20->setAlignment(Qt::AlignCenter);
        tabWidget_2->addTab(tab_4, QString());
        tab_16 = new QWidget();
        tab_16->setObjectName("tab_16");
        label_17 = new QLabel(tab_16);
        label_17->setObjectName("label_17");
        label_17->setGeometry(QRect(250, 160, 581, 51));
        label_17->setFont(font2);
        label_17->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";\n"
"background-color:#007373 ;"));
        label_17->setAlignment(Qt::AlignCenter);
        pushButton_13 = new QPushButton(tab_16);
        pushButton_13->setObjectName("pushButton_13");
        pushButton_13->setGeometry(QRect(500, 280, 83, 29));
        pushButton_13->setFont(font4);
        tabWidget_2->addTab(tab_16, QString());
        tab_17 = new QWidget();
        tab_17->setObjectName("tab_17");
        label_18 = new QLabel(tab_17);
        label_18->setObjectName("label_18");
        label_18->setGeometry(QRect(60, 90, 951, 351));
        sizePolicy1.setHeightForWidth(label_18->sizePolicy().hasHeightForWidth());
        label_18->setSizePolicy(sizePolicy1);
        label_18->setFont(font3);
        label_18->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        label_19 = new QLabel(tab_17);
        label_19->setObjectName("label_19");
        label_19->setGeometry(QRect(440, 20, 241, 41));
        label_19->setFont(font2);
        label_19->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";\n"
"background-color: #007373 ;"));
        label_19->setAlignment(Qt::AlignCenter);
        tabWidget_2->addTab(tab_17, QString());

        verticalLayout_6->addWidget(tabWidget_2);


        verticalLayout_7->addWidget(frame_6);

        stackedWidget->addWidget(page_2);

        verticalLayout_13->addWidget(stackedWidget);


        horizontalLayout->addWidget(frame);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(3);
        tabWidget_4->setCurrentIndex(0);
        tabWidget_7->setCurrentIndex(0);
        stackedWidget_2->setCurrentIndex(1);
        tabWidget_2->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Ask Question", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "Send message", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "Read message", nullptr));
        pushButton_4->setText(QCoreApplication::translate("MainWindow", "View all contacts", nullptr));
        pushButton_7->setText(QCoreApplication::translate("MainWindow", "Add user in contact", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "Remove contact", nullptr));
        pushButton_5->setText(QCoreApplication::translate("MainWindow", "Log out", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "View All Contacts", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "My Contacts", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "Display", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Add user in contact", nullptr));
        lineEdit_6->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter id you want to add him in your contact:", nullptr));
        pushButton_14->setText(QCoreApplication::translate("MainWindow", "ADD", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Remove contact", nullptr));
        lineEdit_7->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter the contact ID that you want to remove:", nullptr));
        pushButton_15->setText(QCoreApplication::translate("MainWindow", "DELETE", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Ask Question", nullptr));
        lineEdit->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter the Question you want to send", nullptr));
        pushButton_8->setText(QCoreApplication::translate("MainWindow", "SEND", nullptr));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_7), QCoreApplication::translate("MainWindow", "Send a Qeustion", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Are you sure you want to remove last sent question ?", nullptr));
        pushButton_9->setText(QCoreApplication::translate("MainWindow", "YES", nullptr));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_8), QCoreApplication::translate("MainWindow", "Remove the last Sent Qeustion", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "My Questions.", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "Display", nullptr));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_11), QCoreApplication::translate("MainWindow", "View all your Qeustion", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "Send Message", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "My  Questions", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "Display", nullptr));
        tabWidget_7->setTabText(tabWidget_7->indexOf(tab_13), QCoreApplication::translate("MainWindow", "View all Question", nullptr));
        lineEdit_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter user id  want to message", nullptr));
        lineEdit_3->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter Id Question You Want To Answer On It From This List:", nullptr));
        lineEdit_8->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter Message You Want To Send It:", nullptr));
        pushButton_16->setText(QCoreApplication::translate("MainWindow", "SEND", nullptr));
        label_23->setText(QCoreApplication::translate("MainWindow", "Display", nullptr));
        pushButton_10->setText(QCoreApplication::translate("MainWindow", "SEND", nullptr));
        tabWidget_7->setTabText(tabWidget_7->indexOf(tab_14), QCoreApplication::translate("MainWindow", "Send a Message", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "My  Messages", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "Display", nullptr));
        tabWidget_7->setTabText(tabWidget_7->indexOf(tab_12), QCoreApplication::translate("MainWindow", "View all Sent Message", nullptr));
        lineEdit_4->setText(QString());
        lineEdit_4->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter Id You Want To Delete The Last Sentmessage", nullptr));
        pushButton_11->setText(QCoreApplication::translate("MainWindow", "DELETE", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "Enter Id You Want To Delete The Last Sentmessage", nullptr));
        tabWidget_7->setTabText(tabWidget_7->indexOf(tab_15), QCoreApplication::translate("MainWindow", " Remove the last Sent Message", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Read message", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "display", nullptr));
        lineEdit_9->setText(QString());
        lineEdit_9->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter the ID that you want to view his message:", nullptr));
        pushButton_18->setText(QCoreApplication::translate("MainWindow", "Display", nullptr));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_3), QCoreApplication::translate("MainWindow", "View all received message", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "display", nullptr));
        lineEdit_5->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter the number of message you want to add in favorite", nullptr));
        pushButton_12->setText(QCoreApplication::translate("MainWindow", "ADD", nullptr));
        label_20->setText(QCoreApplication::translate("MainWindow", "All Messages", nullptr));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_4), QCoreApplication::translate("MainWindow", "Put the message in Favorites", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "Are you sure you want to remove oldest favourite message  ?", nullptr));
        pushButton_13->setText(QCoreApplication::translate("MainWindow", "YES", nullptr));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_16), QCoreApplication::translate("MainWindow", "Remove the oldest message from Favorites", nullptr));
        label_18->setText(QCoreApplication::translate("MainWindow", "display", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "My Favourite Messages", nullptr));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_17), QCoreApplication::translate("MainWindow", "View all Favorites message", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
