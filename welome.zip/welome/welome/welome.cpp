#include "welome.h"
#include<QPixmap>
welome::welome(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::welome)
{
    ui->setupUi(this);
    QPixmap pix("C:/Users/Lenovo/20114/Desktop/unnamed.png");
    int w = ui->label_pic->width();
    int h = ui->label_pic->height();
    ui->label_pic->setPixmap(pix.scaled(w, h, Qt::KeepAspectRatio));
}
void welome::on_pushButton_clicked()
{
    log = new log_in(this);
    log->show();
}
welome::~welome()
{
   
}
