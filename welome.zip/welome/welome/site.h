//#pragma once
//#include "user.h"
//
///*
//	Add_question
//	Send_message
//	Read_message
//
//*/
//class site
//{
//public:
//	int id_user = 1;
//	QVector<user> User;
//	site();
//	void Undo_qeustion();
//	void SendMessageToAllUsers();
//	void Send_Qestion(QString ques);
//	bool SearchAboutContact(int sender_id);
//	void read();
//	void store();
//	~site();
//};