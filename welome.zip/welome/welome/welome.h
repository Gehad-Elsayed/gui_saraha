#pragma once

#include <QtWidgets/QDialog>
#include "ui_welome.h"
#include "log_in.h"
class welome : public QDialog
{
    Q_OBJECT

public:
    welome(QWidget *parent = nullptr);
    ~welome();
private slots:
    void on_pushButton_clicked();
private:
    Ui::welome *ui;
    log_in* log;
};
